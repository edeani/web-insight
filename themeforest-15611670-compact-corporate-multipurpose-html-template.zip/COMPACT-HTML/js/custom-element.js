(function($) { "use strict";

	//Full Accordion				
	$(".accordion").smk_Accordion({
		closeAble: true 
	});
			
	//Full Accordion				
	$(".accordion-1").smk_Accordion({
		closeAble: true 
	});

	//Tabs
	
	
})(jQuery); 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 





	